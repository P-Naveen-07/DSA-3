# Optimal Binary Search Tree for Efficient Search Optimization
**Course:** Data Structures and Algorithms - 3 (25CS2103E) | **Language:** Java | **Run in:** VS Code terminal

A menu-driven console application that builds an Optimal Binary Search Tree (OBST) from sorted keys and
their search frequencies using interval dynamic programming.

## Folder structure
```
OptimalBST_Project/
├── data/
│   ├── obst_dataset.csv        (main dataset: 100 library books)
│   └── obst_sample_small.csv   (tiny 10-row key,frequency example)
├── src/
│   ├── Main.java              (menu and program flow)
│   ├── OptimalBST.java        (DP algorithm, cost table, root table)
│   ├── DataReader.java        (CSV reading and validation)
│   ├── TreeNode.java          (tree node)
│   └── SearchReport.java      (all terminal reports and tree drawing)
└── README.md
```

## Requirements
JDK 11 or newer. Check with `javac -version`.

## Compile and run
Class files are generated **inside `src`** (same as a normal VS Code layout).

From the project root (`OptimalBST_Project`):
```bash
javac src/*.java
java -cp src Main
```
Or from inside `src`:
```bash
javac *.java
java Main
```
The CSV path is resolved automatically from either folder.

## Menu
1. Load dataset from CSV
2. Enter your own keys and frequencies (two input methods)
3. View current dataset
4. Build Optimal BST (Dynamic Programming)
5. View DP Cost Table and Root Table
6. Display Optimal BST structure
7. View Search Cost Report (depth per key, comparison with a balanced BST, brute-force check)
8. Search for a key (shows path and comparisons)
9. View Complexity Analysis
10. Exit

Suggested demo order: `1 -> 4 -> 5 -> 6 -> 7 -> 8 -> 9 -> 10`.

## Algorithm
Minimise `Σ frequency(key) × (depth(key) + 1)` with root depth 0.
```
C[i][i] = freq[i]
C[i][j] = min over r in [i..j] of ( C[i][r-1] + C[r+1][j] + sumFrequency(i,j) )   (empty subtree = 0)
R[i][j] = the r that gives the minimum  -> used to rebuild the tree
```
`sumFrequency(i,j)` is O(1) using prefix sums. `long` is used to avoid overflow.

- **Time:** O(n^3)  **Space:** O(n^2)

## Dataset
`data/obst_dataset.csv` is your 100-record dataset:
```
key,frequency
1001,18
1002,7
```
- Only `key` and `frequency` are required. Extra columns (for example a title) are allowed and shown if the column is named `book_title`, `title`, `name` or `item_name`.
- `data/obst_sample_small.csv` is a tiny 10-row example. In menu option 1 type its name, or press Enter for the main dataset.
- For datasets over 12 keys, option 5 shows a 12-key window of the DP tables (you choose the start position).

## Entering your own keys and frequencies (menu option 2)
- **Method 1:** type all keys on one line, then all frequencies on the next (space or comma separated).
- **Method 2:** enter one key and frequency at a time. Each value is checked immediately (keys must increase, frequencies cannot be negative). Type `done` as the key to finish.

Then choose option 4 to build the tree.

## Dataset rules (validated)
Header must contain `key` and `frequency`; keys distinct and ascending; frequencies non-negative integers; at least one record.
Missing file, malformed rows, duplicates, unsorted keys, negative frequencies and empty data all give a
friendly error message instead of crashing.

## Expected results
- `obst_dataset.csv` (100 keys): root = 1053, minimum cost = 9091 (about 9.9% cheaper than a plain balanced BST).
- `obst_sample_small.csv` (10 keys): root = 60, minimum cost = 124.
- Custom input 10 20 30 with frequencies 3 2 5: root = 30, minimum cost = 17.

## Note about the slide example
For keys 10, 20, 30 with frequencies 3, 2, 5 the true optimum is cost 17 with 30 at the root
(confirmed by the brute-force check), not 18 with 20 at the root as shown on the slide.
