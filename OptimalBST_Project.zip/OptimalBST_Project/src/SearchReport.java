import java.util.ArrayList;

/**
 * SearchReport.java
 * All terminal reports: dataset, DP tables, tree drawing, cost analysis,
 * key search path, and complexity explanation.
 */
public class SearchReport {

    public static void printDataset(int[] keys, int[] freqs, String[] labels) {
        boolean hasLabels = false;
        for (String l : labels) {
            if (!l.isEmpty()) hasLabels = true;
        }
        System.out.println("\n--------- CURRENT DATASET ---------");
        System.out.printf("%-6s %-8s %-10s %s%n", "No.", "Key", "Frequency", hasLabels ? "Title" : "");
        long total = 0;
        int zeros = 0;
        for (int i = 0; i < keys.length; i++) {
            System.out.printf("%-6d %-8d %-10d %s%n", i + 1, keys[i], freqs[i], hasLabels ? labels[i] : "");
            total += freqs[i];
            if (freqs[i] == 0) zeros++;
        }
        System.out.println("Total keys: " + keys.length + " | Total frequency: " + total
                + " | Keys with zero frequency: " + zeros);
    }

    /** Prints a window of up to 'count' keys starting at index 'start' (0-based). */
    public static void printTables(OptimalBST t, int start, int count) {
        int n = t.size();
        int[] keys = t.getKeys();
        int end = Math.min(n, start + count);
        if (n > count) {
            System.out.println("\n(Showing keys " + (start + 1) + " to " + end + " of " + n
                    + ". Full-range cost C[1][" + n + "] = " + t.getMinCost() + ")");
        }
        System.out.println("\n--------- COST TABLE C[i][j] ---------");
        printGrid(keys, start, end, t, true);
        System.out.println("\n--------- ROOT TABLE R[i][j] (shows key) ---------");
        printGrid(keys, start, end, t, false);
        System.out.println("\nRow i = first key of the interval, column j = last key.");
        System.out.println("Each cell is the minimum cost / best root for keys i..j.");
    }

    private static void printGrid(int[] keys, int start, int end, OptimalBST t, boolean costs) {
        System.out.printf("%8s", "");
        for (int j = start; j < end; j++) {
            System.out.printf("%8d", keys[j]);
        }
        System.out.println();
        for (int i = start; i < end; i++) {
            System.out.printf("%8d", keys[i]);
            for (int j = start; j < end; j++) {
                if (j < i) {
                    System.out.printf("%8s", "-");
                } else if (costs) {
                    System.out.printf("%8d", t.getCost()[i][j]);
                } else {
                    System.out.printf("%8d", keys[t.getRoot()[i][j]]);
                }
            }
            System.out.println();
        }
    }

    /** Sideways tree: right subtree on top, left subtree below, root at the left. */
    public static void printTree(TreeNode root) {
        System.out.println("\n--------- OPTIMAL BST STRUCTURE ---------");
        System.out.println("(root on the left; upper branch = right child, lower = left child)\n");
        draw(root, "", true, true);
    }

    private static void draw(TreeNode node, String prefix, boolean isLeft, boolean isRoot) {
        if (node == null) {
            return;
        }
        draw(node.right, prefix + (isRoot ? "" : (isLeft ? "|    " : "     ")), false, false);
        String connector = isRoot ? "" : (isLeft ? "\\--- " : "/--- ");
        System.out.println(prefix + connector + node.key + " (f=" + node.frequency + ")"
                + (node.label.isEmpty() ? "" : " " + node.label));
        draw(node.left, prefix + (isRoot ? "" : (isLeft ? "     " : "|    ")), true, false);
    }

    public static void printCostReport(OptimalBST t) {
        System.out.println("\n--------- SEARCH COST REPORT ---------");
        System.out.printf("%-8s %-10s %-8s %-12s %s%n", "Key", "Frequency", "Depth", "Freq x (d+1)",
                t.hasLabels() ? "Title" : "");
        ArrayList<String> rows = new ArrayList<>();
        collect(t.getTree(), 0, rows);
        for (String r : rows) {
            System.out.println(r);
        }
        long opt = t.getMinCost();
        long bal = t.balancedCost();
        long total = t.getTotalFreq();
        System.out.println("\nMinimum weighted search cost (OBST) : " + opt);
        System.out.println("Cost of plain balanced BST          : " + bal);
        if (bal > 0) {
            System.out.printf("Improvement over balanced BST       : %.2f%%%n",
                    100.0 * (bal - opt) / bal);
        }
        if (total > 0) {
            System.out.printf("Average comparisons per search      : %.3f%n", (double) opt / total);
        }
        System.out.printf("DP build time                       : %.4f ms%n", t.getBuildMillis());
        if (t.size() <= 12) {
            long bf = t.bruteForce();
            System.out.println("Brute-force verification            : " + bf
                    + (bf == opt ? "  (matches DP)" : "  (MISMATCH!)"));
        } else {
            System.out.println("Brute-force verification            : skipped (n > 12)");
        }
    }

    // in-order traversal so rows appear in key order
    private static void collect(TreeNode n, int depth, ArrayList<String> rows) {
        if (n == null) {
            return;
        }
        collect(n.left, depth + 1, rows);
        rows.add(String.format("%-8d %-10d %-8d %-12d %s", n.key, n.frequency, depth,
                (long) n.frequency * (depth + 1), n.label));
        collect(n.right, depth + 1, rows);
    }

    public static void searchKey(TreeNode root, int key) {
        System.out.println("\n--------- SEARCH FOR KEY " + key + " ---------");
        TreeNode cur = root;
        int comparisons = 0;
        StringBuilder path = new StringBuilder();
        while (cur != null) {
            comparisons++;
            path.append(cur.key);
            if (key == cur.key) {
                System.out.println("Path: " + path);
                System.out.println("FOUND after " + comparisons + " comparison(s). Frequency = "
                        + cur.frequency + (cur.label.isEmpty() ? "" : "  Title: " + cur.label));
                return;
            }
            path.append(key < cur.key ? " -> (left) " : " -> (right) ");
            cur = key < cur.key ? cur.left : cur.right;
        }
        System.out.println("Path: " + path + "null");
        System.out.println("NOT FOUND after " + comparisons + " comparison(s).");
    }

    public static void printComplexity() {
        System.out.println("\n--------- COMPLEXITY ANALYSIS ---------");
        System.out.println("Recurrence:");
        System.out.println("  C[i][j] = min over r in [i..j] of ( C[i][r-1] + C[r+1][j] + sumFreq(i,j) )");
        System.out.println("  C[i][i] = freq[i],   empty subtree cost = 0");
        System.out.println("\nTime Complexity : O(n^3)");
        System.out.println("  - O(n^2) intervals (i,j), each tries up to n candidate roots.");
        System.out.println("  - sumFreq(i,j) is O(1) thanks to prefix sums.");
        System.out.println("Space Complexity: O(n^2)");
        System.out.println("  - Cost table and root table each store n x n entries.");
        System.out.println("\nBrute force tries every tree shape (Catalan number, exponential),");
        System.out.println("so dynamic programming is far faster for larger n.");
        System.out.println("Knuth's optimization can reduce the time to O(n^2).");
    }
}
