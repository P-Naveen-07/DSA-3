import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 * DataReader.java
 * Reads and validates the key/frequency dataset (CSV file or typed input).
 *
 * CSV format: a header row followed by data rows. The header MUST contain the
 * columns "key" and "frequency" (any order). Extra columns such as book_id,
 * book_title, category are allowed; "book_title" (or title/name/item_name)
 * is used as a label when present.
 *
 * Validation: no empty dataset, no malformed rows, distinct keys, keys
 * sorted ascending, frequencies non-negative integers.
 */
public class DataReader {

    /** Holds a validated dataset. */
    public static class Dataset {
        public final int[] keys;
        public final int[] freqs;
        public final String[] labels;   // same length as keys; "" when no label

        Dataset(int[] keys, int[] freqs, String[] labels) {
            this.keys = keys;
            this.freqs = freqs;
            this.labels = labels;
        }
    }

    /** Thrown for any invalid dataset; the message is shown to the user. */
    public static class DataException extends Exception {
        public DataException(String message) {
            super(message);
        }
    }

    /**
     * Finds the file whether the program is launched from the project root
     * or from inside the src folder.
     */
    public static File resolvePath(String relativePath) {
        String[] candidates = {
            relativePath,
            "../" + relativePath,
            "OptimalBST_Project/" + relativePath
        };
        for (String c : candidates) {
            File f = new File(c);
            if (f.isFile()) {
                return f;
            }
        }
        return new File(relativePath); // not found; caller reports it
    }

    public static Dataset readCSV(String relativePath) throws DataException {
        File file = resolvePath(relativePath);
        if (!file.isFile()) {
            throw new DataException("Dataset file not found: " + relativePath
                    + "\n  (Run from the project root or the src folder.)");
        }

        ArrayList<Integer> keys = new ArrayList<>();
        ArrayList<Integer> freqs = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            int lineNo = 0;
            int keyIdx = -1, freqIdx = -1, labelIdx = -1, columns = 0;
            boolean headerSeen = false;
            while ((line = br.readLine()) != null) {
                lineNo++;
                line = line.replace("\uFEFF", "").trim();
                if (line.isEmpty()) {
                    continue;
                }
                String[] parts = line.split(",", -1);
                if (!headerSeen) {              // first non-empty line = header
                    headerSeen = true;
                    columns = parts.length;
                    for (int c = 0; c < parts.length; c++) {
                        String h = parts[c].trim().toLowerCase();
                        if (h.equals("key")) keyIdx = c;
                        else if (h.equals("frequency")) freqIdx = c;
                        else if (labelIdx < 0 && (h.equals("book_title") || h.equals("title")
                                || h.equals("name") || h.equals("item_name"))) labelIdx = c;
                    }
                    if (keyIdx < 0 || freqIdx < 0) {
                        throw new DataException("Line " + lineNo
                                + ": header must contain the columns 'key' and 'frequency'.");
                    }
                    continue;
                }
                if (parts.length != columns) {
                    throw new DataException("Line " + lineNo + ": malformed row (expected "
                            + columns + " columns but found " + parts.length + "): '" + line + "'.");
                }
                int key, freq;
                try {
                    key = Integer.parseInt(parts[keyIdx].trim());
                    freq = Integer.parseInt(parts[freqIdx].trim());
                } catch (NumberFormatException e) {
                    throw new DataException("Line " + lineNo
                            + ": 'key' and 'frequency' must be integers in '" + line + "'.");
                }
                keys.add(key);
                freqs.add(freq);
                labels.add(labelIdx >= 0 ? parts[labelIdx].trim() : "");
            }
        } catch (IOException e) {
            throw new DataException("Could not read file: " + e.getMessage());
        }

        return validate(keys, freqs, labels);
    }

    /** Validates parallel lists and converts them to arrays (labels may be null). */
    public static Dataset validate(ArrayList<Integer> keys, ArrayList<Integer> freqs,
                                   ArrayList<String> labels) throws DataException {
        if (keys.isEmpty()) {
            throw new DataException("The dataset is empty. At least one key is required.");
        }
        if (keys.size() != freqs.size()) {
            throw new DataException("Number of keys (" + keys.size()
                    + ") and frequencies (" + freqs.size() + ") must match.");
        }
        int[] k = new int[keys.size()];
        int[] f = new int[keys.size()];
        String[] l = new String[keys.size()];
        for (int i = 0; i < k.length; i++) {
            k[i] = keys.get(i);
            f[i] = freqs.get(i);
            l[i] = (labels == null) ? "" : labels.get(i);
            if (f[i] < 0) {
                throw new DataException("Negative frequency (" + f[i] + ") for key " + k[i] + ".");
            }
            if (i > 0) {
                if (k[i] == k[i - 1]) {
                    throw new DataException("Duplicate key found: " + k[i] + ".");
                }
                if (k[i] < k[i - 1]) {
                    throw new DataException("Keys must be sorted ascending: " + k[i]
                            + " appears after " + k[i - 1] + ".");
                }
            }
        }
        return new Dataset(k, f, l);
    }

    /** Parses a line of integers separated by spaces and/or commas. */
    public static ArrayList<Integer> parseIntegers(String line) throws DataException {
        ArrayList<Integer> out = new ArrayList<>();
        for (String s : line.trim().split("[,\\s]+")) {
            if (s.isEmpty()) {
                continue;
            }
            try {
                out.add(Integer.parseInt(s));
            } catch (NumberFormatException e) {
                throw new DataException("'" + s + "' is not a valid integer.");
            }
        }
        return out;
    }
}
