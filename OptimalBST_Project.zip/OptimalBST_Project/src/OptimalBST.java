/**
 * OptimalBST.java
 * Builds an Optimal Binary Search Tree using interval dynamic programming.
 *
 * Model: successful searches only.
 * Objective: minimize  SUM frequency(key) * (depth(key) + 1)   (root depth = 0)
 *
 * Recurrence (empty subtree cost = 0):
 *   C[i][j] = min over r in [i..j] of ( C[i][r-1] + C[r+1][j] + sumFrequency(i,j) )
 *   R[i][j] = the r that gives the minimum
 *   C[i][i] = freq[i]
 *
 * sumFrequency(i,j) is O(1) using prefix sums.
 * Time: O(n^3)   Space: O(n^2)
 */
public class OptimalBST {
    private final int[] keys;
    private final int[] freqs;
    private final String[] labels;
    private final int n;
    private long[][] cost;      // cost[i][j]: min cost for keys i..j
    private int[][] root;       // root[i][j]: optimal root index for keys i..j
    private long[] prefix;      // prefix[i] = sum of freqs[0..i-1]
    private TreeNode treeRoot;
    private boolean built = false;
    private long buildNanos;

    public OptimalBST(int[] keys, int[] freqs) {
        this(keys, freqs, null);
    }

    public OptimalBST(int[] keys, int[] freqs, String[] labels) {
        this.keys = keys.clone();
        this.freqs = freqs.clone();
        this.labels = (labels == null) ? null : labels.clone();
        this.n = keys.length;
    }

    private long sumFrequency(int i, int j) {
        return prefix[j + 1] - prefix[i];
    }

    /** Runs the DP, fills both tables, and reconstructs the tree. */
    public long build() {
        long start = System.nanoTime();
        cost = new long[n][n];
        root = new int[n][n];
        prefix = new long[n + 1];
        for (int i = 0; i < n; i++) {
            prefix[i + 1] = prefix[i] + freqs[i];   // long avoids overflow
        }
        for (int i = 0; i < n; i++) {               // single-key intervals
            cost[i][i] = freqs[i];
            root[i][i] = i;
        }
        for (int len = 2; len <= n; len++) {        // interval length
            for (int i = 0; i + len - 1 < n; i++) {
                int j = i + len - 1;
                long best = Long.MAX_VALUE;
                int bestRoot = i;
                long sum = sumFrequency(i, j);
                for (int r = i; r <= j; r++) {
                    long left = (r > i) ? cost[i][r - 1] : 0;
                    long right = (r < j) ? cost[r + 1][j] : 0;
                    long total = left + right + sum;
                    if (total < best) {
                        best = total;
                        bestRoot = r;
                    }
                }
                cost[i][j] = best;
                root[i][j] = bestRoot;
            }
        }
        treeRoot = construct(0, n - 1);
        built = true;
        buildNanos = System.nanoTime() - start;
        return cost[0][n - 1];
    }

    /** Reconstructs the tree from the root table. */
    private TreeNode construct(int i, int j) {
        if (i > j) {
            return null;
        }
        int r = root[i][j];
        TreeNode node = new TreeNode(keys[r], freqs[r], labels == null ? "" : labels[r]);
        node.left = construct(i, r - 1);
        node.right = construct(r + 1, j);
        return node;
    }

    public boolean hasLabels() {
        if (labels == null) return false;
        for (String l : labels) {
            if (!l.isEmpty()) return true;
        }
        return false;
    }

    public boolean isBuilt()      { return built; }
    public int size()             { return n; }
    public int[] getKeys()        { return keys; }
    public int[] getFreqs()       { return freqs; }
    public long[][] getCost()     { return cost; }
    public int[][] getRoot()      { return root; }
    public TreeNode getTree()     { return treeRoot; }
    public long getMinCost()      { return cost[0][n - 1]; }
    public long getTotalFreq()    { return prefix[n]; }
    public double getBuildMillis(){ return buildNanos / 1e6; }

    /** Cost of an ordinary (non-optimized) balanced BST on the same keys, for comparison. */
    public long balancedCost() {
        return balanced(0, n - 1, 1);
    }

    private long balanced(int i, int j, int depth) {
        if (i > j) {
            return 0;
        }
        int mid = (i + j) / 2;
        return (long) freqs[mid] * depth + balanced(i, mid - 1, depth + 1)
                + balanced(mid + 1, j, depth + 1);
    }

    /** Exponential brute-force check (only for small n). */
    public long bruteForce() {
        return brute(0, n - 1, 1);
    }

    private long brute(int i, int j, int depth) {
        if (i > j) {
            return 0;
        }
        long best = Long.MAX_VALUE;
        for (int r = i; r <= j; r++) {
            long t = (long) freqs[r] * depth + brute(i, r - 1, depth + 1) + brute(r + 1, j, depth + 1);
            best = Math.min(best, t);
        }
        return best;
    }
}
