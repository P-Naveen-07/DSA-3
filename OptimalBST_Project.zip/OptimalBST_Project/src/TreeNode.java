/**
 * TreeNode.java
 * One node of the Optimal Binary Search Tree.
 */
public class TreeNode {
    int key;
    int frequency;
    String label;      // optional description (e.g. book title); "" if none
    TreeNode left;
    TreeNode right;

    public TreeNode(int key, int frequency, String label) {
        this.key = key;
        this.frequency = frequency;
        this.label = (label == null) ? "" : label;
    }
}
