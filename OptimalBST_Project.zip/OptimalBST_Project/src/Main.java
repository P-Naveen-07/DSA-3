import java.util.ArrayList;
import java.util.Scanner;

/**
 * Main.java
 * Menu-driven console application for the Optimal Binary Search Tree project.
 * DSA-3 (25CS2103E) - Optimal Binary Search Tree for Efficient Search Optimization
 */
public class Main {
    private static final String DEFAULT_CSV = "obst_dataset.csv";
    private static final Scanner sc = new Scanner(System.in);

    private static int[] keys = null;
    private static int[] freqs = null;
    private static String[] labels = null;
    private static OptimalBST bst = null;

    public static void main(String[] args) {
        System.out.println("==================================================");
        System.out.println("   OPTIMAL BINARY SEARCH TREE (OBST) SYSTEM");
        System.out.println("   Efficient Search Optimization using Dynamic Programming");
        System.out.println("   DSA-3 (25CS2103E)");
        System.out.println("==================================================");

        boolean running = true;
        while (running) {
            printMenu();
            int choice = readChoice();
            switch (choice) {
                case 1:  loadCsv(); break;
                case 2:  enterCustom(); break;
                case 3:  if (hasData()) SearchReport.printDataset(keys, freqs, labels); break;
                case 4:  buildTree(); break;
                case 5:  if (hasTree()) showTables(); break;
                case 6:  if (hasTree()) SearchReport.printTree(bst.getTree()); break;
                case 7:  if (hasTree()) SearchReport.printCostReport(bst); break;
                case 8:  searchKey(); break;
                case 9:  SearchReport.printComplexity(); break;
                case 10: running = false; break;
                default: System.out.println("\n[!] Invalid choice. Enter a number from 1 to 10.");
            }
        }
        System.out.println("\nThank you for using the Optimal BST system!");
    }

    private static void printMenu() {
        System.out.println("\n================= MAIN MENU =================");
        System.out.println("1.  Load dataset from CSV file (data folder)");
        System.out.println("2.  Enter your own keys and frequencies (type input)");
        System.out.println("3.  View current dataset");
        System.out.println("4.  Build Optimal BST (Dynamic Programming)");
        System.out.println("5.  View DP Cost Table and Root Table");
        System.out.println("6.  Display Optimal BST structure");
        System.out.println("7.  View Search Cost Report");
        System.out.println("8.  Search for a key");
        System.out.println("9.  View Complexity Analysis");
        System.out.println("10. Exit");
        System.out.print("\nEnter your choice: ");
    }

    private static int readChoice() {
        if (!sc.hasNextLine()) {
            return 10;                       // input closed -> exit cleanly
        }
        String line = sc.nextLine().trim();
        try {
            return Integer.parseInt(line);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static boolean hasData() {
        if (keys == null) {
            System.out.println("\n[!] No dataset loaded. Use option 1 or 2 first.");
            return false;
        }
        return true;
    }

    private static boolean hasTree() {
        if (!hasData()) {
            return false;
        }
        if (bst == null || !bst.isBuilt()) {
            System.out.println("\n[!] Tree not built yet. Use option 4 first.");
            return false;
        }
        return true;
    }

    private static void loadCsv() {
        System.out.print("\nCSV file name in the data folder [" + DEFAULT_CSV + "]: ");
        String name = sc.hasNextLine() ? sc.nextLine().trim() : "";
        if (name.isEmpty()) {
            name = DEFAULT_CSV;
        }
        try {
            DataReader.Dataset d = DataReader.readCSV("data/" + name);
            keys = d.keys;
            freqs = d.freqs;
            labels = d.labels;
            bst = null;
            System.out.println("\n[OK] Loaded " + keys.length + " records from " + name + ".");
        } catch (DataReader.DataException e) {
            System.out.println("\n[Error] " + e.getMessage());
        }
    }

    /** Large tables are shown as a window of at most 12 keys. */
    private static void showTables() {
        int n = bst.size();
        int start = 0;
        if (n > 12) {
            System.out.print("\nDataset has " + n + " keys. Enter start position 1-" + (n - 12 + 1)
                    + " for a 12-key window [1]: ");
            String line = sc.hasNextLine() ? sc.nextLine().trim() : "";
            if (!line.isEmpty()) {
                try {
                    start = Integer.parseInt(line) - 1;
                } catch (NumberFormatException e) {
                    System.out.println("[!] Not a number, using position 1.");
                    start = 0;
                }
                if (start < 0 || start > n - 12) {
                    System.out.println("[!] Out of range, using position 1.");
                    start = 0;
                }
            }
        }
        SearchReport.printTables(bst, start, 12);
    }

    private static void enterCustom() {
        System.out.println("\n--------- ENTER YOUR OWN DATA ---------");
        System.out.println("1. Type all keys, then all frequencies (one line each)");
        System.out.println("2. Enter one key and frequency at a time");
        System.out.println("3. Cancel");
        System.out.print("Choose input method: ");
        int method = readChoice();
        if (method == 1) {
            enterAllAtOnce();
        } else if (method == 2) {
            enterOneByOne();
        } else if (method != 3) {
            System.out.println("\n[!] Invalid choice. Returning to the main menu.");
        }
    }

    private static void enterAllAtOnce() {
        try {
            System.out.println("\nEnter keys in ascending order (space or comma separated).");
            System.out.print("Keys        : ");
            ArrayList<Integer> k = DataReader.parseIntegers(sc.nextLine());
            System.out.print("Frequencies : ");
            ArrayList<Integer> f = DataReader.parseIntegers(sc.nextLine());
            acceptCustom(DataReader.validate(k, f, null));
        } catch (DataReader.DataException e) {
            System.out.println("\n[Error] " + e.getMessage());
        } catch (java.util.NoSuchElementException e) {
            System.out.println("\n[Error] No input received.");
        }
    }

    /** Each pair is checked immediately; type 'done' to finish. */
    private static void enterOneByOne() {
        ArrayList<Integer> k = new ArrayList<>();
        ArrayList<Integer> f = new ArrayList<>();
        System.out.println("\nEnter keys in ascending order. Type 'done' as the key to finish.");
        try {
            while (true) {
                System.out.print("Key #" + (k.size() + 1) + " (or 'done'): ");
                String keyLine = sc.nextLine().trim();
                if (keyLine.equalsIgnoreCase("done")) {
                    break;
                }
                int key;
                try {
                    key = Integer.parseInt(keyLine);
                } catch (NumberFormatException e) {
                    System.out.println("  [!] Enter a whole number or 'done'.");
                    continue;
                }
                if (!k.isEmpty() && key <= k.get(k.size() - 1)) {
                    System.out.println("  [!] Key must be greater than the previous key ("
                            + k.get(k.size() - 1) + ").");
                    continue;
                }
                System.out.print("Frequency of " + key + "     : ");
                int freq;
                try {
                    freq = Integer.parseInt(sc.nextLine().trim());
                } catch (NumberFormatException e) {
                    System.out.println("  [!] Frequency must be a whole number. Try this key again.");
                    continue;
                }
                if (freq < 0) {
                    System.out.println("  [!] Frequency cannot be negative. Try this key again.");
                    continue;
                }
                k.add(key);
                f.add(freq);
            }
            acceptCustom(DataReader.validate(k, f, null));
        } catch (DataReader.DataException e) {
            System.out.println("\n[Error] " + e.getMessage());
        } catch (java.util.NoSuchElementException e) {
            System.out.println("\n[Error] No input received.");
        }
    }

    private static void acceptCustom(DataReader.Dataset d) {
        keys = d.keys;
        freqs = d.freqs;
        labels = d.labels;
        bst = null;
        System.out.println("\n[OK] Custom dataset accepted (" + keys.length + " keys).");
        System.out.println("Tip: choose option 4 to build the Optimal BST.");
    }

    private static void buildTree() {
        if (!hasData()) {
            return;
        }
        bst = new OptimalBST(keys, freqs, labels);
        long cost = bst.build();
        System.out.println("\n[OK] Optimal BST built successfully.");
        System.out.println("Root key: " + bst.getTree().key);
        System.out.println("Minimum expected search cost: " + cost);
    }

    private static void searchKey() {
        if (!hasTree()) {
            return;
        }
        System.out.print("\nEnter key to search: ");
        try {
            int key = Integer.parseInt(sc.nextLine().trim());
            SearchReport.searchKey(bst.getTree(), key);
        } catch (NumberFormatException e) {
            System.out.println("\n[Error] Please enter a valid integer key.");
        } catch (java.util.NoSuchElementException e) {
            System.out.println("\n[Error] No input received.");
        }
    }
}
